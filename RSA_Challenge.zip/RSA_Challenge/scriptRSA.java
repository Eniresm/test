import java.io.*;
import java.math.*;

public class scriptRSA {

public static void main(String[] args){

BigInteger p,n,e,d,phi,q,pMinus1,qMinus1,e1,e2,coef;

n=new BigInteger("");
q=new BigInteger("2");
p=new BigInteger("2");
phi=new BigInteger("1");
e=new BigInteger("65537");


}

}
